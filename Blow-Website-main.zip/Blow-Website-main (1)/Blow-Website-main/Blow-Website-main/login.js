const mysql=require("mysql");
const express =require("express");

const connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password:"1234",
    database:"login"
});

connection.connect(function(error){
    if(error) throw error
    else console.log("connected to the database successfully!")
});


app.get("/",function(req,res){
    res.sendFile(__dirname +"/Login.html");
})

app.post("/",encoder,function(req,res){

    var username =req.body.username;
    var password = req.body.password;

    connection.query("select *from loginpage where username=kumariharshita682@gmail.com and password=password", function(error,results,fields){
        if(results.length>0){
            res.redirect("/welcome");
        }else{
            res.redirect("/");
        }
        res.end();
    })
}) 



app.listen(3000);
